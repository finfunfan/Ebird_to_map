# Life list

A map of every species on my eBird life list, plus a chart of how much of each bird family I have seen. Static site for GitHub Pages: no server, no build step.

## Publish on GitHub Pages

1. In GitHub Desktop: File → New repository, then copy all files from this folder into it (keep `.github` and `.nojekyll`).
2. Commit and click "Publish repository".
3. On github.com: repository Settings → Pages → Source "Deploy from a branch" → branch `main`, folder `/ (root)` → Save.
4. The site appears at `https://<username>.github.io/<repository>/` after a minute.

## Update my data

1. eBird → My eBird → Download my data. Unzip and replace `data/MyEBirdData.csv`.
2. eBird → My eBird → Life list (World) → Download. Save it as `data/ebird_world_life_list.csv`. This file only marks escapees, so the total matches eBird.
3. Commit and push.

Anyone visiting the site can also load their own eBird files with "Load eBird files" or by dropping them onto the page. Those files are read in the browser and never uploaded.

**Privacy:** in a public repository, `MyEBirdData.csv` publishes the coordinates of every observation, including personal locations. To avoid that, leave the two CSV files out of the repository and load them in the browser instead.

## Taxonomy

`data/taxonomy.json` holds the eBird/Clements taxonomy (v2025, living species only). The Families view uses it for family and order totals.

The workflow in `.github/workflows/update-taxonomy.yml` runs on the 1st of every month and commits a new `taxonomy.json` when Cornell publishes a new version. Without any setup it reads Cornell Lab's own copy of the taxonomy in the [auk repository](https://github.com/CornellLabofOrnithology/auk).

Optional, for the newest version straight from eBird and for species names in another language:

1. Get a key at https://ebird.org/api/keygen.
2. Repository Settings → Secrets and variables → Actions → New repository secret, name `EBIRD_API_KEY`.
3. Actions → Update eBird taxonomy → Run workflow. Enter a language code (for example `de`) or leave it empty for English.

You can also build it from a downloaded taxonomy CSV:

```
python3 scripts/build_taxonomy.py --csv eBird_taxonomy_v2026.csv
```

## Preview locally

```
python3 -m http.server 8000
```

Then open http://localhost:8000. Opening `index.html` directly from disk does not work, because browsers block loading the data files that way.

## Credits

- Bird data: [eBird](https://ebird.org), Cornell Lab of Ornithology. Taxonomy: eBird/Clements Checklist of Birds of the World.
- Map tiles: © [OpenStreetMap](https://www.openstreetmap.org/copyright) contributors.
- Included libraries: [Leaflet](https://leafletjs.com) 1.9.4 (BSD-2), [D3](https://d3js.org) 7.9.0 (ISC), [Papa Parse](https://www.papaparse.com) 5.4.1 (MIT). Licence files are in `lib/`.
- Fonts: Spectral and Barlow (SIL Open Font License), in `fonts/`.
