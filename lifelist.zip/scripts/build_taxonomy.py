"""Build data/taxonomy.json (orders, families, living species) for the Families view.

Sources, in order of preference when run without arguments:
  1. eBird API, if EBIRD_API_KEY is set (newest taxonomy, names in any eBird locale via LOCALE)
  2. Cornell Lab's own copy of the eBird taxonomy in the "auk" repository (no key needed)

Other options:
  python scripts/build_taxonomy.py --auk                 # force source 2
  python scripts/build_taxonomy.py --csv eBird_taxonomy_v2026.csv
        # a taxonomy CSV downloaded from https://www.birds.cornell.edu/clementschecklist/download/

Extinct species are left out, so family totals only count birds that can still be seen.

Output (compact JSON):
  {"version", "locale", "source", "orders": [name],
   "families": [[sciName, comName, orderIndex]],
   "species":  [[sciName, comName, familyIndex]]}      # taxonomic order
"""

import csv
import io
import json
import os
import re
import sys
import urllib.request
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "data" / "taxonomy.json"
API = "https://api.ebird.org/v2"
AUK = "https://raw.githubusercontent.com/CornellLabofOrnithology/auk/main/data-raw"


def get(url, headers=None):
    req = urllib.request.Request(url, headers=headers or {"User-Agent": "lifelist-taxonomy-builder"})
    with urllib.request.urlopen(req, timeout=180) as r:
        return r.read().decode("utf-8-sig")


def truthy(v):
    return str(v).strip().lower() in ("true", "1", "yes", "y")


def pick(row, *names):
    lowered = {k.strip().lower(): v for k, v in row.items() if k}
    for n in names:
        v = lowered.get(n.lower())
        if v not in (None, ""):
            return str(v).strip()
    return ""


def rows_from_csv_text(text):
    """Accepts Cornell's eBird taxonomy CSV and the auk copy of it (different column names)."""
    rows = []
    for r in csv.DictReader(io.StringIO(text)):
        if pick(r, "CATEGORY", "category").lower() != "species":
            continue
        if truthy(pick(r, "extinct", "EXTINCT")):
            continue
        family = pick(r, "FAMILY", "family")
        fam_com = pick(r, "family_common", "FAMILY_COMMON")
        if not fam_com and " (" in family:  # Cornell CSV: "Ardeidae (Herons, Egrets, and Bitterns)"
            family, _, rest = family.partition(" (")
            fam_com = rest.rstrip(")")
        rows.append(
            {
                "order": pick(r, "ORDER", "ORDER1", "order"),
                "taxon_order": float(pick(r, "TAXON_ORDER", "taxonomic_order", "taxon_order") or 0),
                "sci": pick(r, "SCI_NAME", "scientific_name", "sci_name"),
                "com": pick(r, "PRIMARY_COM_NAME", "common_name", "com_name"),
                "fam_sci": family.strip(),
                "fam_com": fam_com.strip(),
            }
        )
    return rows


def from_api(key, locale):
    headers = {"X-eBirdApiToken": key}
    taxa = json.loads(get(f"{API}/ref/taxonomy/ebird?fmt=json&cat=species&locale={locale}", headers))
    version = "unknown"
    try:
        latest = [v for v in json.loads(get(f"{API}/ref/taxonomy/versions", headers)) if v.get("latest")]
        if latest:
            version = str(latest[0].get("authorityVer"))
    except Exception as err:  # informative only
        print(f"Could not read taxonomy version: {err}")
    rows = [
        {
            "order": t.get("order", ""),
            "taxon_order": float(t.get("taxonOrder", 0)),
            "sci": t["sciName"],
            "com": t["comName"],
            "fam_sci": t.get("familySciName", ""),
            "fam_com": t.get("familyComName", ""),
        }
        for t in taxa
        if t.get("category") == "species" and not t.get("extinct")
    ]
    return rows, version, locale, "eBird API"


def from_auk():
    text = get(f"{AUK}/ebird-taxonomy.csv")
    recipe = get(f"{AUK}/ebird-taxonomy.r")
    m = re.search(r"eBird_taxonomy_v(\d{4})", recipe)
    return rows_from_csv_text(text), m.group(1) if m else "unknown", "en", "Cornell Lab auk repository"


def from_csv(path):
    text = Path(path).read_text(encoding="utf-8-sig")
    digits = re.findall(r"20\d\d", Path(path).name)
    return rows_from_csv_text(text), digits[-1] if digits else "csv", "en", Path(path).name


def build(rows, version, locale, source):
    if not rows:
        sys.exit("No species rows found; taxonomy.json left unchanged.")
    rows.sort(key=lambda r: r["taxon_order"])
    orders, order_idx, families, family_idx, species = [], {}, [], {}, []
    for r in rows:
        if r["order"] not in order_idx:
            order_idx[r["order"]] = len(orders)
            orders.append(r["order"])
        if r["fam_sci"] not in family_idx:
            family_idx[r["fam_sci"]] = len(families)
            families.append([r["fam_sci"], r["fam_com"], order_idx[r["order"]]])
        species.append([r["sci"], r["com"], family_idx[r["fam_sci"]]])
    payload = {
        "version": version,
        "locale": locale,
        "source": f"eBird/Clements taxonomy v{version}, Cornell Lab of Ornithology ({source}); extinct species excluded",
        "orders": orders,
        "families": families,
        "species": species,
    }
    OUT.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print(f"Wrote {OUT}: v{version}, {len(species)} living species, {len(families)} families, {len(orders)} orders ({source}, {locale})")


def current_locale():
    try:
        return json.loads(OUT.read_text(encoding="utf-8")).get("locale") or "en"
    except Exception:
        return "en"


if __name__ == "__main__":
    args = sys.argv[1:]
    # LOCALE set → use it; empty (scheduled runs) → keep the language already in taxonomy.json
    locale = os.environ.get("LOCALE") or current_locale()
    key = os.environ.get("EBIRD_API_KEY")
    if len(args) == 2 and args[0] == "--csv":
        build(*from_csv(args[1]))
    elif args == ["--auk"]:
        build(*from_auk())
    elif key:
        build(*from_api(key, locale))
    elif locale != "en":
        sys.exit(f"Names in '{locale}' need the eBird API: add an EBIRD_API_KEY repository secret.")
    else:
        build(*from_auk())
