// Loads data/taxonomy.json and builds the order → family → species tree.

export async function loadTaxonomy(url = "data/taxonomy.json") {
  const res = await fetch(url, { cache: "no-cache" });
  if (!res.ok) throw new Error(`Could not load ${url} (${res.status})`);
  const raw = await res.json();
  const families = raw.families.map(([sci, name, orderIdx], i) => ({ id: `f${i}`, sci, name, order: raw.orders[orderIdx] }));
  const species = raw.species.map(([sci, name, famIdx]) => ({ sci, name, family: families[famIdx] }));
  const bySci = new Map(species.map((s) => [s.sci, s]));
  const genusToFamily = new Map();
  for (const s of species) {
    const genus = s.sci.split(" ")[0];
    if (!genusToFamily.has(genus)) genusToFamily.set(genus, s.family);
  }
  return { version: raw.version, locale: raw.locale, orders: raw.orders, families, species, bySci, genusToFamily };
}

// seen: Map sci → taxon (from the dataset). Escapees are shown but not counted. Species missing from the taxonomy
// (e.g. new splits) are attached to their family via the genus.
export function buildTree(taxonomy, seen) {
  const placed = new Set();
  const famNodes = new Map();
  const orderNodes = new Map();

  for (const order of taxonomy.orders) {
    orderNodes.set(order, { id: `o:${order}`, rank: "order", name: order, sci: order, children: [] });
  }
  for (const f of taxonomy.families) {
    const node = { id: `f:${f.sci}`, rank: "family", name: f.name || f.sci, sci: f.sci, order: f.order, children: [] };
    famNodes.set(f.sci, node);
    orderNodes.get(f.order).children.push(node);
  }
  for (const s of taxonomy.species) {
    const taxon = seen.get(s.sci);
    if (taxon) placed.add(s.sci);
    famNodes.get(s.family.sci).children.push({
      id: `s:${s.sci}`,
      rank: "species",
      name: taxon ? taxon.name : s.name,
      sci: s.sci,
      seen: Boolean(taxon && !taxon.escapee),
      escapee: Boolean(taxon && taxon.escapee),
    });
  }

  const unplaced = [];
  for (const [sci, taxon] of seen) {
    if (placed.has(sci)) continue;
    const fam = taxonomy.genusToFamily.get(sci.split(" ")[0]);
    if (fam) {
      famNodes.get(fam.sci).children.push({ id: `s:${sci}`, rank: "species", name: taxon.name, sci, seen: !taxon.escapee, escapee: taxon.escapee, added: true });
    } else {
      unplaced.push(taxon);
    }
  }

  const root = { id: "root", rank: "root", name: "All birds", sci: "", children: [...orderNodes.values()] };
  return { root, unplaced, famNodes };
}
