// Parsing and aggregation of eBird exports.
// MyEBirdData.csv  → one row per observation (all taxa, incl. forms, sp., slashes, hybrids)
// life-list CSV    → one row per taxon, with eBird's "Countable" flag (escapees = 0)

export function parseCsv(text) {
  const res = Papa.parse(text, { header: true, skipEmptyLines: true, transformHeader: (h) => h.trim() });
  return res.data;
}

export function detectFileType(rows) {
  const cols = rows.length ? Object.keys(rows[0]) : [];
  if (cols.includes("Submission ID") && cols.includes("Scientific Name")) return "observations";
  if (cols.includes("Countable") && cols.includes("Scientific Name")) return "lifelist";
  return null;
}

// Category of a reported name, following eBird's own categories.
export function classify(common, sci) {
  const base = common.replace(/\(.*?\)/g, "");
  if (/\(hybrid\)/i.test(common)) return "hybrid";
  if (/ sp\./.test(common)) return "spuh";
  if (base.includes("/")) return "slash";
  if (/\(Domestic type\)/i.test(common)) return "domestic";
  if (common.includes("(")) return "form";
  return "species";
}

// "Anas platyrhynchos (Domestic type)" → "Anas platyrhynchos"; "Larus michahellis atlantis" → "Larus michahellis"
export function speciesKey(sci) {
  return sci.replace(/\(.*?\)/g, " ").trim().split(/\s+/).slice(0, 2).join(" ");
}

const stripParen = (s) => s.replace(/\s*\(.*?\)\s*/g, " ").trim();

function toNumber(v) {
  const n = parseFloat(v);
  return Number.isFinite(n) ? n : null;
}

export function buildDataset(obsRows, lifeRows, taxonomy) {
  const taxa = new Map(); // key → taxon
  const locations = new Map(); // locId → location

  for (const r of obsRows) {
    const common = (r["Common Name"] || "").trim();
    const sci = (r["Scientific Name"] || "").trim();
    if (!common || !sci) continue;
    const lat = toNumber(r["Latitude"]);
    const lng = toNumber(r["Longitude"]);
    const cat = classify(common, sci);
    const isSpecies = cat === "species" || cat === "form" || cat === "domestic";
    const key = isSpecies ? speciesKey(sci) : sci;

    let t = taxa.get(key);
    if (!t) {
      t = {
        key,
        kind: isSpecies ? "species" : cat,
        sci: isSpecies ? key : sci,
        name: isSpecies ? stripParen(common) : common,
        hasPlainName: false,
        taxonOrder: Infinity,
        records: [],
        lastDate: "",
        escapee: false,
      };
      taxa.set(key, t);
    }
    if (cat === "species" && !t.hasPlainName) {
      t.name = common;
      t.hasPlainName = true;
    }
    const tOrder = toNumber(r["Taxonomic Order"]);
    if (tOrder !== null) {
      if (cat === "species") t.plainOrder = tOrder;
      t.taxonOrder = Math.min(t.taxonOrder, tOrder);
    }

    const locId = r["Location ID"] || `${lat},${lng}`;
    const rec = {
      date: r["Date"] || "",
      time: r["Time"] || "",
      lat,
      lng,
      locId,
      locName: r["Location"] || "Unnamed location",
      region: r["State/Province"] || "",
      count: r["Count"] || "",
      subId: r["Submission ID"] || "",
      reported: cat === "form" || cat === "domestic" ? common : "",
    };
    t.records.push(rec);
    if (rec.date > t.lastDate) t.lastDate = rec.date;

    if (lat !== null && lng !== null) {
      let loc = locations.get(locId);
      if (!loc) {
        loc = { locId, lat, lng, name: rec.locName, region: rec.region, checklists: new Set(), species: new Set(), lastDate: "" };
        locations.set(locId, loc);
      }
      if (rec.subId) loc.checklists.add(rec.subId);
      if (isSpecies) loc.species.add(key);
      if (rec.date > loc.lastDate) loc.lastDate = rec.date;
    }
  }

  // Names from the taxonomy file only when it is in another language (set by the GitHub Action);
  // otherwise keep eBird's own names from the export.
  if (taxonomy && taxonomy.locale && taxonomy.locale !== "en") {
    for (const t of taxa.values()) {
      if (t.kind !== "species") continue;
      const tx = taxonomy.bySci.get(t.sci);
      if (tx) t.name = tx.name;
    }
  }

  // Escapees from the life-list export.
  let lifeLoaded = false;
  if (lifeRows && lifeRows.length) {
    lifeLoaded = true;
    for (const r of lifeRows) {
      if ((r["Category"] || "").trim() !== "species") continue;
      if (String(r["Countable"]).trim() !== "0") continue;
      const t = taxa.get(speciesKey(r["Scientific Name"] || ""));
      if (t) t.escapee = true;
    }
  }

  for (const t of taxa.values()) {
    t.records.sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time));
    if (t.plainOrder !== undefined) t.taxonOrder = t.plainOrder;
    if (!Number.isFinite(t.taxonOrder)) t.taxonOrder = 1e9;
  }

  const all = [...taxa.values()];
  const species = all.filter((t) => t.kind === "species");
  const countable = species.filter((t) => !t.escapee);

  return {
    taxa,
    list: all,
    species,
    countable,
    locations: [...locations.values()],
    lifeLoaded,
    checklistCount: new Set(obsRows.map((r) => r["Submission ID"])).size,
  };
}

// Group a taxon's records by location for the map.
export function groupByLocation(taxon) {
  const groups = new Map();
  for (const rec of taxon.records) {
    if (rec.lat === null || rec.lng === null) continue;
    let g = groups.get(rec.locId);
    if (!g) {
      g = { locId: rec.locId, lat: rec.lat, lng: rec.lng, name: rec.locName, region: rec.region, visits: [] };
      groups.set(rec.locId, g);
    }
    g.visits.push(rec);
  }
  return [...groups.values()];
}

const dateFmt = new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "short", year: "numeric" });

export function formatDate(iso) {
  if (!iso) return "No date";
  const d = new Date(iso + "T12:00:00");
  return Number.isNaN(d.getTime()) ? iso : dateFmt.format(d);
}

export function normalise(s) {
  return s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

export function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
