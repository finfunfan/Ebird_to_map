import { groupByLocation, formatDate, escapeHtml } from "./data.js";

const INK = "#17262a";
const OCHRE = "#d49b1c";
const MUTED = "#56676a";

export function createMap(el) {
  const map = L.map(el, { preferCanvas: true, worldCopyJump: true, zoomControl: true }).setView([30, 10], 2);
  L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors. Data: <a href="https://ebird.org">eBird</a>',
  }).addTo(map);

  const baseLayer = L.layerGroup().addTo(map);
  const speciesLayer = L.layerGroup().addTo(map);
  let baseMarkers = [];
  let allBounds = null;

  function centreOn(e) {
    // Same behaviour as the original map: clicking a marker centres it, keeping the zoom.
    map.setView(e.target.getLatLng(), map.getZoom(), { animate: true });
  }

  function showLocations(locations) {
    baseLayer.clearLayers();
    baseMarkers = [];
    const pts = [];
    for (const loc of locations) {
      const m = L.circleMarker([loc.lat, loc.lng], {
        radius: 4,
        color: "#fff",
        weight: 1,
        fillColor: MUTED,
        fillOpacity: 0.75,
      });
      m.bindTooltip(`${escapeHtml(loc.name)}<br>${loc.species.size} species, ${loc.checklists.size} checklist${loc.checklists.size === 1 ? "" : "s"}`, { direction: "top", offset: [0, -4] });
      m.bindPopup(
        `<p class="pop-title">${escapeHtml(loc.name)}</p>
         <p class="pop-sub">${escapeHtml(loc.region)}. Last visit ${formatDate(loc.lastDate)}</p>
         <p>${loc.species.size} species on ${loc.checklists.size} checklist${loc.checklists.size === 1 ? "" : "s"}</p>`
      );
      m.on("click", centreOn);
      m.addTo(baseLayer);
      baseMarkers.push(m);
      pts.push([loc.lat, loc.lng]);
    }
    allBounds = pts.length ? L.latLngBounds(pts) : null;
    if (allBounds) map.fitBounds(allBounds, { padding: [30, 30], maxZoom: 10 });
  }

  function dimBase(dim) {
    for (const m of baseMarkers) m.setStyle({ fillOpacity: dim ? 0.18 : 0.75, opacity: dim ? 0.3 : 1 });
  }

  function showSpecies(taxon) {
    speciesLayer.clearLayers();
    dimBase(true);
    const groups = groupByLocation(taxon);
    const pts = [];
    const maxVisits = Math.max(1, ...groups.map((g) => g.visits.length));
    for (const g of groups) {
      const latest = g.visits[0];
      const radius = 7 + 7 * Math.sqrt((g.visits.length - 1) / Math.max(1, maxVisits - 1));
      const m = L.circleMarker([g.lat, g.lng], {
        radius,
        color: INK,
        weight: 1.5,
        fillColor: OCHRE,
        fillOpacity: 0.92,
      });
      const visitsTxt = g.visits.length === 1 ? "1 record" : `${g.visits.length} records`;
      m.bindTooltip(
        `<b>${escapeHtml(taxon.name)}</b><br>${escapeHtml(g.name)}<br>${formatDate(latest.date)}${g.visits.length > 1 ? ` (${visitsTxt})` : ""}`,
        { direction: "top", offset: [0, -radius] }
      );
      const rows = g.visits
        .map(
          (v) => `<li><span>${formatDate(v.date)}${v.count && v.count !== "X" ? `, ${escapeHtml(v.count)}` : ""}${v.reported ? `<br><span class="pop-form">${escapeHtml(v.reported)}</span>` : ""}</span>${
            v.subId ? `<a href="https://ebird.org/checklist/${encodeURIComponent(v.subId)}" target="_blank" rel="noopener">Checklist</a>` : ""
          }</li>`
        )
        .join("");
      m.bindPopup(
        `<p class="pop-title">${escapeHtml(taxon.name)}</p>
         <p class="pop-sub">${escapeHtml(g.name)}. ${visitsTxt}</p>
         <ul class="pop-list">${rows}</ul>`
      );
      m.on("click", centreOn);
      m.addTo(speciesLayer);
      pts.push([g.lat, g.lng]);
    }
    if (pts.length === 1) map.setView(pts[0], Math.max(map.getZoom(), 9));
    else if (pts.length) map.fitBounds(L.latLngBounds(pts), { padding: [60, 60], maxZoom: 11 });
    return groups.length;
  }

  function clearSpecies() {
    speciesLayer.clearLayers();
    dimBase(false);
    if (allBounds) map.fitBounds(allBounds, { padding: [30, 30], maxZoom: 10 });
  }

  return { map, showLocations, showSpecies, clearSpecies, refresh: () => map.invalidateSize() };
}
