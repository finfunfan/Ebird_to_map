// Zoomable sunburst: orders → families → species, coloured by how much you have seen.
// At the root it shows orders and families; inside an order, families plus a seen/unseen
// ring per family; inside a family, every species.

const SEEN = "#d49b1c";
const ESCAPEE = "#efd9a3";
const UNSEEN = "#d8e0db";
const SPLIT_UNSEEN = "#ccd6d0";
const completion = d3
  .scaleSequentialSqrt(d3.interpolateRgbBasis(["#d3ddd7", "#8db5a6", "#3e7d6c", "#1c5547"]))
  .domain([0, 1]);

const TAU = 2 * Math.PI;
const nf = new Intl.NumberFormat("en-GB");
const pct = (a, b) => (b ? `${Math.round((100 * a) / b)}%` : "0%");

export function createSunburst(container, { tooltip, onSpecies, onFocus }) {
  const svg = d3.select(container).append("svg").attr("role", "img").attr("aria-label", "Family completion chart");
  let root = null;
  let focus = null;
  let current = null; // current <g>
  let size = 0;
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function setData(tree) {
    root = d3.hierarchy(tree).sum((d) => (d.children ? 0 : 1));
    root.eachAfter((n) => {
      n.seen = n.children ? d3.sum(n.children, (c) => c.seen) : n.data.seen ? 1 : 0;
      n.familiesSeen = n.data.rank === "family" ? (n.seen > 0 ? 1 : 0) : n.children ? d3.sum(n.children, (c) => c.familiesSeen || 0) : 0;
    });
    d3.partition().size([TAU, root.height + 1])(root);
    focus = root;
    render(null);
    onFocus?.(focus);
  }

  const rel = (d, f) => {
    const span = f.x1 - f.x0;
    return [((d.x0 - f.x0) / span) * TAU, ((d.x1 - f.x0) / span) * TAU];
  };

  function measure() {
    const rect = container.getBoundingClientRect();
    return Math.max(260, Math.min(rect.width, rect.height));
  }

  function arcsFor(f, r) {
    const arcs = [];
    const isFamily = f.data.rank === "family";
    const ring1 = isFamily ? [r * 0.34, r] : [r * 0.34, r * 0.655];
    const ring2 = [r * 0.67, r];
    for (const c of f.children || []) {
      const [a0, a1] = rel(c, f);
      arcs.push({ node: c, a0, a1, ri: ring1[0], ro: ring1[1], ring: 1 });
      if (isFamily || !c.children) continue;
      if (f.depth === 0) {
        for (const g of c.children) {
          const [b0, b1] = rel(g, f);
          arcs.push({ node: g, a0: b0, a1: b1, ri: ring2[0], ro: ring2[1], ring: 2 });
        }
      } else if (f.value <= 1500) {
        // inside an order: every species
        for (const g of c.children) {
          const [b0, b1] = rel(g, f);
          arcs.push({ node: g, a0: b0, a1: b1, ri: ring2[0], ro: ring2[1], ring: 2 });
        }
      } else {
        // very large orders (passerines): one seen/unseen split per family instead of thousands of slivers
        const cut = a0 + (a1 - a0) * (c.seen / c.value);
        if (c.seen > 0) arcs.push({ node: c, a0, a1: cut, ri: ring2[0], ro: ring2[1], ring: 2, share: "seen", start: true, end: c.seen === c.value });
        if (c.seen < c.value) arcs.push({ node: c, a0: cut, a1, ri: ring2[0], ro: ring2[1], ring: 2, share: "unseen", start: c.seen === 0, end: true });
      }
    }
    return arcs;
  }

  function fillFor(a) {
    const d = a.node;
    if (a.share === "seen") return SEEN;
    if (a.share === "unseen") return SPLIT_UNSEEN;
    if (d.data.rank === "species") return d.data.seen ? SEEN : d.data.escapee ? ESCAPEE : UNSEEN;
    return completion(d.seen / d.value);
  }

  function labelFor(a, thickness) {
    const d = a.node;
    const maxChars = Math.floor((thickness - 10) / 6.3);
    if (maxChars < 4) return "";
    // Orders and families by scientific name (consistent, compact); species by common name.
    const options = d.data.rank === "species" ? [d.data.name] : [d.data.sci];
    for (const o of options) if (o && o.length <= maxChars) return o;
    const o = options[options.length - 1] || "";
    return o.length > maxChars ? `${o.slice(0, maxChars - 1)}…` : o;
  }

  function tooltipHtml(a) {
    const d = a.node;
    const t = d.data;
    if (t.rank === "species") {
      const state = t.seen ? "Seen" : t.escapee ? "Seen as escapee, not countable" : "Not yet seen";
      return `<b>${t.name}</b><br><em>${t.sci}</em><br>${state}${t.seen ? ". Click to show on the map" : ""}`;
    }
    const sci = t.rank === "family" && t.sci !== t.name ? `<br><em>${t.sci}</em>` : "";
    const fams = t.rank === "order" ? `<br>${d.familiesSeen} of ${d.children.length} families` : "";
    return `<b>${t.name}</b>${sci}<br>${nf.format(d.seen)} of ${nf.format(d.value)} species (${pct(d.seen, d.value)})${fams}`;
  }

  function showTip(evt, html) {
    tooltip.innerHTML = html;
    tooltip.hidden = false;
    const pad = 14;
    const { innerWidth: w, innerHeight: h } = window;
    const rect = tooltip.getBoundingClientRect();
    let x = evt.clientX + pad;
    let y = evt.clientY + pad;
    if (x + rect.width > w - 8) x = evt.clientX - rect.width - pad;
    if (y + rect.height > h - 8) y = evt.clientY - rect.height - pad;
    tooltip.style.left = `${x}px`;
    tooltip.style.top = `${y}px`;
  }

  const hideTip = () => (tooltip.hidden = true);

  function activate(a) {
    const d = a.node;
    if (d.data.rank === "species") {
      if (d.data.seen || d.data.escapee) onSpecies?.(d.data.sci);
      return;
    }
    if (d.children) zoomTo(d);
  }

  function centerText(g, f, r0) {
    const c = g.append("g").attr("class", "center");
    c.append("circle").attr("r", r0).attr("fill", "#f7f9f7");
    const fsT = Math.max(12, Math.min(18, r0 * 0.15));
    const fsB = Math.max(20, Math.min(30, r0 * 0.27));
    const fsS = Math.max(10, Math.min(13, r0 * 0.115));
    const title = f.data.rank === "root" ? "All birds" : f.data.name;
    const maxLine = Math.max(8, Math.floor((r0 * 1.6) / (fsT * 0.56)));
    const lines = [];
    for (const w of title.split(/\s+/)) {
      if (lines.length && (lines[lines.length - 1] + " " + w).length <= maxLine) lines[lines.length - 1] += " " + w;
      else lines.push(w);
    }
    const shown = lines.slice(0, 2);
    if (lines.length > 2) shown[1] = `${shown[1].slice(0, maxLine - 1)}…`;
    const top = -r0 * 0.36 - (shown.length - 1) * fsT * 0.6;
    shown.forEach((l, i) =>
      c.append("text").attr("class", "center-title").attr("text-anchor", "middle").attr("y", top + i * fsT * 1.18).style("font-size", `${fsT}px`).text(l)
    );
    c.append("text").attr("class", "center-big").attr("text-anchor", "middle").attr("y", r0 * 0.14).style("font-size", `${fsB}px`).text(nf.format(f.seen));
    c.append("text").attr("class", "center-sub").attr("text-anchor", "middle").attr("y", r0 * 0.38).style("font-size", `${fsS}px`).text(`of ${nf.format(f.value)} species (${pct(f.seen, f.value)})`);
    const third = c.append("text").attr("class", "center-sub").attr("text-anchor", "middle").attr("y", r0 * 0.38 + fsS * 1.5).style("font-size", `${fsS}px`);
    if (f.data.rank === "family" && f.data.sci !== f.data.name) {
      third.attr("font-style", "italic").text(f.data.sci);
    } else if (f.data.rank === "order" || f.data.rank === "root") {
      const famCount = f.data.rank === "root" ? root.descendants().filter((n) => n.data.rank === "family").length : f.children.length;
      third.text(`${f.familiesSeen} of ${famCount} families`);
    }
    if (f.parent) {
      c.attr("tabindex", 0).attr("role", "button").attr("aria-label", "Zoom out");
      c.on("click", () => zoomTo(f.parent)).on("keydown", (e) => (e.key === "Enter" || e.key === " ") && (e.preventDefault(), zoomTo(f.parent)));
      c.append("title").text("Zoom out");
    } else {
      c.style("cursor", "default");
    }
  }

  function render(direction) {
    if (!root) return;
    size = measure();
    const r = size / 2 - 2;
    svg.attr("viewBox", [-size / 2, -size / 2, size, size]).attr("width", size).attr("height", size);

    const g = svg.append("g").attr("class", "burst");
    const arcGen = d3
      .arc()
      .startAngle((a) => a.a0)
      .endAngle((a) => a.a1)
      .innerRadius((a) => a.ri)
      .outerRadius((a) => a.ro)
      .padAngle((a) => (a.share && !(a.start && a.end) ? 0 : Math.min((a.a1 - a.a0) / 3, 0.003)))
      .padRadius(r * 0.5);

    const arcs = arcsFor(focus, r);
    g.append("g")
      .selectAll("path")
      .data(arcs)
      .join("path")
      .attr("d", arcGen)
      .attr("fill", fillFor)
      .attr("class", (a) => (a.node.data.rank === "species" && !a.node.data.seen && !a.node.data.escapee ? "leaf-unseen" : null))
      .attr("tabindex", (a) => (a.ring === 1 && (a.node.children || a.node.data.seen) ? 0 : null))
      .attr("role", (a) => (a.ring === 1 ? "button" : null))
      .attr("aria-label", (a) => (a.ring === 1 ? `${a.node.data.name}: ${a.node.seen} of ${a.node.value} seen` : null))
      .on("pointermove", (e, a) => showTip(e, tooltipHtml(a)))
      .on("pointerleave", hideTip)
      .on("click", (e, a) => (hideTip(), activate(a)))
      .on("keydown", (e, a) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          activate(a);
        }
      });

    // Radial labels where there is room.
    g.append("g")
      .selectAll("text")
      .data(arcs.filter((a) => !a.share && (a.a1 - a.a0) * ((a.ri + a.ro) / 2) > 13))
      .join("text")
      .attr("class", (a) => `arc-label${d3.hsl(fillFor(a)).l < 0.45 ? " on-dark" : ""}`)
      .attr("dy", "0.35em")
      .attr("transform", (a) => {
        const angle = (((a.a0 + a.a1) / 2) * 180) / Math.PI;
        const radius = (a.ri + a.ro) / 2;
        return `rotate(${angle - 90}) translate(${radius},0) rotate(${angle < 180 ? 0 : 180})`;
      })
      .attr("text-anchor", "middle")
      .text((a) => labelFor(a, a.ro - a.ri));

    centerText(g, focus, r * 0.33);

    const old = current;
    current = g;
    if (!old) return;
    if (!direction || reduceMotion) {
      old.remove();
      return;
    }
    const inScale = direction === "in" ? 0.82 : 1.18;
    const outScale = direction === "in" ? 1.18 : 0.82;
    g.attr("opacity", 0).attr("transform", `scale(${inScale})`);
    g.transition().duration(280).ease(d3.easeCubicOut).attr("opacity", 1).attr("transform", "scale(1)");
    old.transition().duration(220).attr("opacity", 0).attr("transform", `scale(${outScale})`).remove();
  }

  function zoomTo(node) {
    if (!node || node === focus) return;
    const direction = node.depth > focus.depth ? "in" : "out";
    focus = node;
    hideTip();
    render(direction);
    onFocus?.(focus);
  }

  function zoomToId(id) {
    if (!root) return;
    const node = root.descendants().find((n) => n.data.id === id);
    if (node) zoomTo(node.children ? node : node.parent);
  }

  new ResizeObserver(() => {
    if (!root || !container.offsetParent) return;
    const s = measure();
    if (Math.abs(s - size) > 4) {
      current?.remove();
      current = null;
      render(null);
    }
  }).observe(container);

  return {
    setData,
    zoomTo,
    zoomToId,
    getRoot: () => root,
    getFocus: () => focus,
    redraw: () => {
      current?.remove();
      current = null;
      render(null);
    },
  };
}
