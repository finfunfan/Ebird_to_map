import { parseCsv, detectFileType, buildDataset, formatDate, normalise, escapeHtml } from "./data.js";
import { loadTaxonomy, buildTree } from "./taxonomy.js";
import { createMap } from "./map.js";
import { createSunburst } from "./sunburst.js";

const $ = (id) => document.getElementById(id);
const nf = new Intl.NumberFormat("en-GB");

const state = {
  obsRows: null,
  lifeRows: null,
  taxonomy: null,
  data: null,
  tree: null,
  selected: null,
  view: "map",
  familyRows: [],
  selectedFamily: null,
};

// Header height drives the app height.
const header = document.querySelector(".top");
new ResizeObserver(() => document.documentElement.style.setProperty("--header-h", `${header.offsetHeight}px`)).observe(header);

const mapApi = createMap($("map"));
const sunburst = createSunburst($("sunburst"), {
  tooltip: $("tooltip"),
  onSpecies: (sci) => selectSpecies(sci),
  onFocus: (focus) => {
    renderCrumbs(focus);
    state.selectedFamily = focus.data.rank === "family" ? focus.data.id : null;
    markFamily();
    if (state.view === "families") setHash(focus.data.rank === "root" ? "families" : `families/${focus.data.id}`);
  },
});

/* Loading ------------------------------------------------------------------ */

async function fetchText(url) {
  try {
    const res = await fetch(url, { cache: "no-cache" });
    if (!res.ok) return null;
    return await res.text();
  } catch {
    return null;
  }
}

async function boot() {
  try {
    state.taxonomy = await loadTaxonomy();
  } catch (err) {
    console.warn(err);
    $("tax-note").textContent = "The taxonomy file (data/taxonomy.json) is missing, so the Families view is unavailable.";
  }

  const [obsText, lifeText] = await Promise.all([fetchText("data/MyEBirdData.csv"), fetchText("data/ebird_world_life_list.csv")]);
  if (obsText) {
    const rows = parseCsv(obsText);
    if (detectFileType(rows) === "observations") state.obsRows = rows;
  }
  if (lifeText) {
    const rows = parseCsv(lifeText);
    if (detectFileType(rows) === "lifelist") state.lifeRows = rows;
  }
  if (state.obsRows) {
    rebuild();
    routeFromHash();
  } else {
    $("empty").hidden = false;
    $("tally-note").textContent = "No data loaded yet.";
  }
}

async function loadFiles(files) {
  const problems = [];
  for (const file of files) {
    const rows = parseCsv(await file.text());
    const type = detectFileType(rows);
    if (type === "observations") state.obsRows = rows;
    else if (type === "lifelist") state.lifeRows = rows;
    else problems.push(file.name);
  }
  if (state.obsRows) {
    $("empty").hidden = true;
    state.selected = null;
    rebuild();
  }
  if (problems.length) {
    $("tally-note").textContent = `Not recognised as an eBird export: ${problems.join(", ")}. Use MyEBirdData.csv or the life-list CSV.`;
  }
}

/* Build -------------------------------------------------------------------- */

function rebuild() {
  const data = buildDataset(state.obsRows, state.lifeRows, state.taxonomy);
  state.data = data;

  $("tally-num").textContent = nf.format(data.countable.length);
  $("tally-label").textContent = "species";
  const escapees = data.species.length - data.countable.length;
  $("tally-note").textContent = data.lifeLoaded
    ? escapees
      ? `${escapees} escapee${escapees === 1 ? "" : "s"} not counted, as on eBird. ${nf.format(data.checklistCount)} checklists.`
      : `${nf.format(data.checklistCount)} checklists.`
    : "Escapees are included. Load your life-list file to leave them out, as eBird does.";
  document.title = `Life list: ${data.countable.length}`;

  mapApi.showLocations(data.locations);
  hideMapBar();
  renderSpeciesList();

  if (state.taxonomy) {
    const seen = new Map(data.species.map((t) => [t.sci, t]));
    state.tree = buildTree(state.taxonomy, seen);
    sunburst.setData(state.tree.root);
    buildFamilyRows();
    renderFamilyList();
    const added = state.tree.root.children
      .flatMap((o) => o.children)
      .flatMap((f) => f.children)
      .filter((s) => s.added).length;
    const notes = [`Taxonomy: eBird/Clements v${state.taxonomy.version}, living species only.`];
    if (added) notes.push(`${added} species newer than this taxonomy ${added === 1 ? "was" : "were"} placed by genus.`);
    if (state.tree.unplaced.length) notes.push(`Not placed: ${state.tree.unplaced.map((t) => t.name).join(", ")}.`);
    $("tax-note").textContent = notes.join(" ");
  }
}

/* Species list ------------------------------------------------------------- */

const KIND_TAG = { spuh: "sp.", slash: "slash", hybrid: "hybrid" };

function renderSpeciesList() {
  const { data } = state;
  if (!data) return;
  const q = normalise($("species-search").value.trim());
  const includeOther = $("include-other").checked;
  const sort = $("species-sort").value;

  let items = data.list.filter((t) => t.kind === "species" || includeOther);
  const total = items.length;
  if (q) items = items.filter((t) => normalise(t.name).includes(q) || normalise(t.sci).includes(q));

  const byName = (a, b) => a.name.localeCompare(b.name);
  const sorters = {
    recent: (a, b) => (b.lastDate || "").localeCompare(a.lastDate || "") || byName(a, b),
    taxonomic: (a, b) => a.taxonOrder - b.taxonOrder,
    alpha: byName,
    records: (a, b) => b.records.length - a.records.length || byName(a, b),
  };
  items.sort(sorters[sort]);

  $("species-list").innerHTML = items
    .map((t) => {
      const tag = t.escapee ? '<span class="tag">escapee</span>' : KIND_TAG[t.kind] ? `<span class="tag">${KIND_TAG[t.kind]}</span>` : "";
      return `<li><button class="item" data-key="${escapeHtml(t.key)}"${t.key === state.selected ? ' aria-current="true"' : ""}>
        <span class="item-name">${escapeHtml(t.name)}${tag}</span>
        <span class="item-sci">${escapeHtml(t.sci)}</span>
        <span class="item-num" title="Records">${t.records.length}</span>
      </button></li>`;
    })
    .join("");
  $("species-meta").textContent = q ? `${items.length} of ${total} shown` : `${total} in list`;
}

$("species-list").addEventListener("click", (e) => {
  const btn = e.target.closest(".item");
  if (btn) selectSpecies(btn.dataset.key);
});
$("species-search").addEventListener("input", renderSpeciesList);
$("species-sort").addEventListener("change", renderSpeciesList);
$("include-other").addEventListener("change", renderSpeciesList);

function selectSpecies(key) {
  const taxon = state.data?.taxa.get(key);
  if (!taxon) return;
  state.selected = key;
  setView("map");
  for (const el of document.querySelectorAll("#species-list .item")) {
    if (el.dataset.key === key) {
      el.setAttribute("aria-current", "true");
      el.scrollIntoView({ block: "nearest" });
    } else el.removeAttribute("aria-current");
  }
  const places = mapApi.showSpecies(taxon);
  const n = taxon.records.length;
  $("map-bar-name").textContent = taxon.name;
  $("map-bar-sub").textContent = places
    ? `${n} record${n === 1 ? "" : "s"} at ${places} location${places === 1 ? "" : "s"}. Latest ${formatDate(taxon.lastDate)}.`
    : "No records with coordinates.";
  $("map-bar").hidden = false;
  setHash(`species/${encodeURIComponent(key)}`);
}

function hideMapBar() {
  $("map-bar").hidden = true;
}

$("clear-selection").addEventListener("click", () => {
  state.selected = null;
  hideMapBar();
  mapApi.clearSpecies();
  document.querySelectorAll('#species-list .item[aria-current="true"]').forEach((el) => el.removeAttribute("aria-current"));
  setHash("map");
});

/* Family list -------------------------------------------------------------- */

function buildFamilyRows() {
  const root = sunburst.getRoot();
  const families = root.descendants().filter((n) => n.data.rank === "family");
  state.familyRows = families.map((n, i) => ({ id: n.data.id, name: n.data.name, sci: n.data.sci, order: n.parent.data.name, seen: n.seen, total: n.value, idx: i }));
  const orders = root.children;
  $("fam-seen").textContent = families.filter((n) => n.seen > 0).length;
  $("fam-total").textContent = families.length;
  $("ord-seen").textContent = orders.filter((n) => n.seen > 0).length;
  $("ord-total").textContent = orders.length;
}

function renderFamilyList() {
  const q = normalise($("family-search").value.trim());
  const filter = $("family-filter").value;
  const sort = $("family-sort").value;
  let rows = state.familyRows.slice();
  if (filter === "seen") rows = rows.filter((r) => r.seen > 0);
  if (filter === "missing") rows = rows.filter((r) => r.seen === 0);
  if (q) rows = rows.filter((r) => normalise(r.name).includes(q) || normalise(r.sci).includes(q) || normalise(r.order).includes(q));
  const sorters = {
    taxonomic: (a, b) => a.idx - b.idx,
    complete: (a, b) => b.seen / b.total - a.seen / a.total || b.seen - a.seen,
    gap: (a, b) => b.total - b.seen - (a.total - a.seen),
  };
  rows.sort(sorters[sort]);
  $("family-list").innerHTML = rows
    .map(
      (r) => `<li><button class="item" data-id="${escapeHtml(r.id)}"${r.id === state.selectedFamily ? ' aria-current="true"' : ""}>
        <span class="item-name">${escapeHtml(r.name)}</span>
        <span class="item-sci">${escapeHtml(r.sci)}</span>
        <span class="item-num">${r.seen}/${r.total}</span>
        <span class="bar" aria-hidden="true"><i style="width:${((100 * r.seen) / r.total).toFixed(1)}%"></i></span>
      </button></li>`
    )
    .join("");
  $("family-meta").textContent = `${rows.length} ${rows.length === 1 ? "family" : "families"} shown`;
}

function markFamily() {
  for (const el of document.querySelectorAll("#family-list .item")) {
    if (el.dataset.id === state.selectedFamily) {
      el.setAttribute("aria-current", "true");
      el.scrollIntoView({ block: "nearest" });
    } else el.removeAttribute("aria-current");
  }
}

$("family-list").addEventListener("click", (e) => {
  const btn = e.target.closest(".item");
  if (btn) sunburst.zoomToId(btn.dataset.id);
});
$("family-search").addEventListener("input", renderFamilyList);
$("family-filter").addEventListener("change", renderFamilyList);
$("family-sort").addEventListener("change", renderFamilyList);

function renderCrumbs(focus) {
  const path = focus.ancestors().reverse();
  $("crumbs").innerHTML = path
    .map((n, i) => {
      const label = n.data.rank === "root" ? "All birds" : n.data.name;
      return i === path.length - 1
        ? `<span>${escapeHtml(label)}</span>`
        : `<button data-id="${escapeHtml(n.data.id)}">${escapeHtml(label)}</button><span class="sep">/</span>`;
    })
    .join("");
}

$("crumbs").addEventListener("click", (e) => {
  const btn = e.target.closest("button");
  if (!btn) return;
  const node = sunburst.getRoot().descendants().find((n) => n.data.id === btn.dataset.id);
  if (node) sunburst.zoomTo(node);
});

/* Views & routing ------------------------------------------------------------ */

function setView(view) {
  if (state.view === view && !$(`view-${view}`).hidden) return;
  state.view = view;
  const isMap = view === "map";
  $("tab-map").setAttribute("aria-selected", String(isMap));
  $("tab-families").setAttribute("aria-selected", String(!isMap));
  $("view-map").hidden = !isMap;
  $("view-families").hidden = isMap;
  $("side-species").hidden = !isMap;
  $("side-families").hidden = isMap;
  if (isMap) mapApi.refresh();
  else {
    sunburst.redraw();
    const f = sunburst.getFocus();
    setHash(!f || f.data.rank === "root" ? "families" : `families/${f.data.id}`);
  }
}

for (const tab of document.querySelectorAll(".tab")) {
  tab.addEventListener("click", () => {
    setView(tab.dataset.view);
    if (tab.dataset.view === "map") setHash(state.selected ? `species/${encodeURIComponent(state.selected)}` : "map");
  });
}

function setHash(h) {
  history.replaceState(null, "", `#${h}`);
}

function routeFromHash() {
  if (!state.data) return;
  const h = decodeURIComponent(location.hash.slice(1));
  if (h.startsWith("species/")) selectSpecies(h.slice(8));
  else if (h.startsWith("families")) {
    setView("families");
    const id = h.slice(9);
    if (id) sunburst.zoomToId(id);
  } else if (h === "map") setView("map");
}

// Manual edits of the address bar (replaceState above does not fire this).
window.addEventListener("hashchange", routeFromHash);

/* File input & drag-and-drop ---------------------------------------------------- */

$("file-input").addEventListener("change", (e) => {
  if (e.target.files.length) loadFiles([...e.target.files]);
  e.target.value = "";
});

let dragDepth = 0;
window.addEventListener("dragenter", (e) => {
  if (![...(e.dataTransfer?.types || [])].includes("Files")) return;
  dragDepth++;
  $("drop").hidden = false;
});
window.addEventListener("dragleave", () => {
  dragDepth = Math.max(0, dragDepth - 1);
  if (!dragDepth) $("drop").hidden = true;
});
window.addEventListener("dragover", (e) => e.preventDefault());
window.addEventListener("drop", (e) => {
  e.preventDefault();
  dragDepth = 0;
  $("drop").hidden = true;
  const files = [...(e.dataTransfer?.files || [])].filter((f) => /\.csv$/i.test(f.name) || f.type === "text/csv");
  if (files.length) loadFiles(files);
});

boot();
